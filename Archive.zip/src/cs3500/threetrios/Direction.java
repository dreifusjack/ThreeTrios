package cs3500.threetrios;

public enum Direction {
  NORTH, EAST, SOUTH, WEST;
}
